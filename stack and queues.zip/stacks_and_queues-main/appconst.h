#ifndef APPCONSTANT_H_INCLUDED
#define APPCONSTANT_H_INCLUDED

#define MAX_DEPTH 32
#define STACK_OK 1
#define STACK_EMPTY 2
#define STACK_FULL 3

#define Q_LEN 32
#define QUEUE_OK 1
#define QUEUE_EMPTY 2
#define QUEUE_FULL 3



#endif // APPCONSTANT_H_INCLUDED
